/*jslint vars: true , plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global bm_eventDispatcher, File, Folder*/
var bm_main = (function () {
    'use strict';
    var ob = {};

    return ob;
}());